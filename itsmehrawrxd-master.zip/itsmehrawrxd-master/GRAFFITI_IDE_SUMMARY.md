# 🔥 GRAFFITI IDE - ULTIMATE HACKER'S WORKSPACE 🔥

## Overview
A comprehensive IDE system with spray-painted code graffiti backgrounds, animated compilation gears, old-school forum themes, and local AI integration - inspired by legendary hack forums and IRC channels.

## 🎨 Core Features

### 1. Graffiti Code Wall (`graffiti_ide_wall.py`)
- **Spray-painted code wall background** with brick texture
- **Real code snippets** from legendary hack forums and projects
- **Transparent floating panels** over graffiti background
- **Draggable panels** with hacker-themed content
- **Animated graffiti effects** with spray paint drips

#### Code Categories:
- **Assembly graffiti**: `mov eax, 0x12345678`, `push ebp`, `int 0x80`
- **C++ memory hacking**: `VirtualAlloc`, `LoadLibraryA`, `CONTEXT ctx`
- **Python exploitation**: `ctypes`, `inject_shellcode`, `MemoryScanner`
- **JavaScript obfuscation**: `eval(atob())`, `window['\\x65\\x76\\x61\\x6c']`
- **PHP backdoors**: `<?php eval($_POST['cmd']); ?>`
- **Batch scripts**: `net user admin /add`, `reg add HKLM`
- **Lua game hacks**: `SetHealth(999)`, `hook.Add("Think", "GodMode")`
- **Ruby exploits**: `TCPSocket.new()`, `system("nc -l -p 4444")`
- **Go shellcode injection**: `syscall.Exec`, `injectShellcode`

### 2. Compilation Gears Animation (`compilation_gears_animation.py`)
- **Spinning mechanical gears** during compilation
- **Code spitters** that shoot out assembly code fragments
- **Real-time compilation animation** with physics
- **Multiple gear systems** with different speeds and colors
- **Code particles** with gravity and fade effects

#### Gear Types:
- **Main drive gear**: Large orange gear (center)
- **Secondary gears**: Medium gears in different colors
- **Small gears**: Fast-spinning gears with high rotation speed
- **Code spitters**: Shoot assembly code like `mov eax, 1`, `push ebp`, `call 0x401000`

### 3. Old-School Forum Themes
- **UnknownCheats.me**: Dark GitHub-style theme
- **HackForums.net**: Black/orange hacker theme
- **Game-Deception**: Matrix green on black
- **vBulletin Classic**: Clean white/blue forum style
- **WordPress Classic**: Professional blue/gray
- **mIRC Classic**: Retro blue/yellow IRC colors
- **CS Cheat Servers**: Green/red gaming theme
- **OGC Elite**: Orange/black elite theme
- **iC JAPS**: Blue/gold professional theme
- **Death Elf**: Red/black dark theme

### 4. Local AI Compiler Manager (`local_ai_compiler_manager.py`)
- **Ollama integration** for local AI models
- **Tabby support** for real-time code completion
- **LocalAI compatibility** for OpenAI API
- **Continue-style** context-aware chat
- **Code analysis** with CodeT5-style prompts
- **Online compiler integration** with Judge0/Piston
- **Model management** with pull/test functionality

## 🚀 Advanced Features

### Transparent Panel System
- **Floating panels** with semi-transparent backgrounds
- **Draggable interface** elements
- **See-through effects** showing graffiti underneath
- **Professional styling** with hacker aesthetics

### Code Editor Features
- **Syntax highlighting** for multiple languages
- **Line numbers** with graffiti styling
- **Code completion** with AI assistance
- **Real-time compilation** with gear animation
- **Memory viewer** with hex dumps
- **Process hacker** interface
- **Network monitor** for traffic analysis

### AI Integration
- **Local model support** (Llama2, CodeLlama, Mistral, etc.)
- **Real-time completion** with Tabby
- **Context-aware chat** with project file analysis
- **Code generation** with compilation execution
- **Online fallback** with Judge0/Piston APIs

## 🎯 Usage Instructions

### Quick Start
```bash
# Run the main graffiti IDE
python graffiti_ide_wall.py

# Run compilation gears demo
python compilation_gears_animation.py

# Run AI compiler manager
python test_local_ai_compiler.py

# Run full features demo
python demo_graffiti_ide_features.py
```

### AI Model Setup
```bash
# Start Ollama
ollama serve

# Pull a model
ollama pull codellama:7b

# Test the model
ollama run codellama:7b "Write a Python keylogger"
```

### Theme Application
1. Open the AI Compiler Manager
2. Click on any forum theme button
3. Theme is applied to the entire IDE
4. Graffiti background adapts to theme colors

### Compilation with Gears
1. Write code in the editor
2. Click "🔥 COMPILE WITH GEARS"
3. Watch gears spin and code spit out
4. See real-time compilation output
5. Generated code can be executed

## 💀 Elite Features

### Hacker Aesthetics
- **Matrix-style** green text on black
- **Spray-painted** code graffiti everywhere
- **Elite signatures** like "HACKED BY ELITE", "PWNED", "1337"
- **Memory addresses** as graffiti: `0x401000`, `0xDEADBEEF`
- **Assembly instructions** scattered: `JMP`, `CALL`, `PUSH`, `XOR`

### Real Code Integration
- **Actual exploit code** from security research
- **Memory manipulation** techniques
- **Process injection** methods
- **Shellcode examples** and injection techniques
- **Network exploitation** tools and scripts

### Professional Tools
- **Hex editor** with memory visualization
- **Process explorer** with injection capabilities
- **Network sniffer** for traffic analysis
- **Password cracker** interface
- **Virus signature** database integration

## 🔧 Technical Implementation

### Architecture
- **Modular design** with separate components
- **Event-driven** animation system
- **Threaded** compilation processes
- **Canvas-based** graphics rendering
- **Plugin system** for AI services

### Performance
- **Optimized rendering** for smooth animations
- **Background processing** for AI operations
- **Memory efficient** graffiti caching
- **Responsive UI** with non-blocking operations

### Integration Points
- **Main IDE** integration through `complete_n0mn0m_universal_ide.py`
- **AI services** integration through `local_ai_compiler_manager.py`
- **Theme system** integration across all components
- **Graffiti system** integration with transparent panels

## 🎨 Visual Design

### Color Schemes
- **Primary**: Matrix green (`#00ff00`) on black (`#000000`)
- **Accent**: Orange (`#ff6600`) for highlights
- **Error**: Red (`#ff0000`) for warnings
- **Success**: Green (`#00ff41`) for completion
- **Info**: Blue (`#0066ff`) for information

### Typography
- **Primary font**: Consolas (monospace for code)
- **Headers**: Arial Black or Impact (for graffiti effect)
- **UI elements**: Verdana or Arial (for readability)
- **Code**: Courier New (classic terminal style)

### Animation Effects
- **Gear rotation**: Smooth mechanical spinning
- **Code spitting**: Physics-based particle system
- **Graffiti spraying**: Random position and rotation
- **Panel transparency**: See-through floating elements
- **Theme transitions**: Smooth color changes

## 🚀 Future Enhancements

### Planned Features
- **3D gear system** with depth and shadows
- **Sound effects** for compilation and graffiti
- **More AI models** integration (GPT, Claude, etc.)
- **Collaborative editing** with real-time sync
- **Plugin marketplace** for extensions
- **Cloud synchronization** for projects
- **Mobile app** version for on-the-go hacking

### Advanced Integrations
- **Docker containers** for isolated compilation
- **Kubernetes** for distributed processing
- **Blockchain** for code verification
- **IoT device** programming support
- **Quantum computing** simulation
- **AR/VR** immersive coding environment

## 💀 Conclusion

The Graffiti IDE represents the ultimate fusion of:
- **Old-school hacker aesthetics** from legendary forums
- **Modern AI-powered** development tools
- **Visual flair** with animated compilation gears
- **Professional functionality** for serious development
- **Nostalgic themes** from the golden age of hacking

This is not just an IDE - it's a **work of art** that pays homage to the hacker culture while providing cutting-edge development capabilities. Whether you're writing assembly exploits, Python automation scripts, or web applications, the Graffiti IDE provides the perfect environment for elite-level programming.

🔥 **HACK THE MATRIX** 🔥
